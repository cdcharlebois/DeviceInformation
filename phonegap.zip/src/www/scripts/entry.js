var MxApp = require("mendix-hybrid-app-base");

MxApp.onConfigReady(function(config) {
    // Perform any custom operations on the dojoConfig object here
});

MxApp.onClientReady(function(mx) {
    // Perform any custom operations on the Mendix client object here
});
